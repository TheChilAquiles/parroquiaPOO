<?php

// ============================================================================
// InformacionController.php
// ============================================================================

class InformacionController
{
    public function mostrar()
    {
        include __DIR__ . '/../Vista/informacion.php';
    }
}