<?php

// ============================================================================
// HomeController.php
// ============================================================================

class HomeController
{
    public function index()
    {
        include_once __DIR__ . '/../Vista/home.php';
    }
}